The tpl.php files were removed from FullCalendar. This adds extra processing to bring them back.
