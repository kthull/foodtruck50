<?php
print '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
?>
<feed xmlns="http://www.w3.org/2005/Atom"
      xmlns:dc="http://purl.org/dc/elements/1.1/"  xmlns:flickr="urn:flickr:" xmlns:media="http://search.yahoo.com/mrss/">

	<title>Content from My picks</title>
	<link rel="self" href="http://api.flickr.com/services/feeds/photoset.gne?set=72157603970496952&amp;nsid=28242329@N00&amp;lang=en-us" />
	<link rel="alternate" type="text/html" href="http://www.flickr.com/photos/a-barth/sets/72157603970496952"/>
	<id>tag:flickr.com,2005:http://www.flickr.com/photos/28242329@N00/sets/72157603970496952</id>
	<icon>http://farm1.static.flickr.com/42/86410049_bd6dcdd5f9_s.jpg</icon>
	<subtitle>Some of my shots I like best in random order.</subtitle>
	<updated>2009-07-09T21:48:04Z</updated>
	<generator uri="http://www.flickr.com/">Flickr</generator>

	<entry>
		<title>Tubing is awesome</title>
		<link rel="alternate" type="text/html" href="http://www.flickr.com/photos/a-barth/3596408735/in/set-72157603970496952/"/>
		<id>tag:flickr.com,2005:/photo/3596408735/in/set-72157603970496952</id>
		<published>2009-07-09T21:48:04Z</published>
		<updated>2009-07-09T21:48:04Z</updated>
                <dc:date.Taken>2009-05-01T00:00:00-08:00</dc:date.Taken>
		<content type="html">&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/people/a-barth/&quot;&gt;Alex Barth&lt;/a&gt; posted a photo:&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/photos/a-barth/3596408735/&quot; title=&quot;Tubing is awesome&quot;&gt;&lt;img src=&quot;http://farm4.static.flickr.com/3599/3596408735_ce2f0c4824_m.jpg&quot; width=&quot;240&quot; height=&quot;161&quot; alt=&quot;Tubing is awesome&quot; /&gt;&lt;/a&gt;&lt;/p&gt;


&lt;p&gt;Virginia, 2009&lt;/p&gt;</content>
		<author>
			<name>Alex Barth</name>
			<uri>http://www.flickr.com/people/a-barth/</uri>
					</author>
		<link rel="license" type="text/html" href="http://creativecommons.org/licenses/by-nc/2.0/deed.en" />
        <link rel="enclosure" type="image/jpeg" href="<?php print $image_urls[0]; ?>" />

		<category term="color" scheme="http://www.flickr.com/photos/tags/" />
		<category term="film" scheme="http://www.flickr.com/photos/tags/" />
		<category term="virginia" scheme="http://www.flickr.com/photos/tags/" />
		<category term="awesome" scheme="http://www.flickr.com/photos/tags/" />
		<category term="ishootfilm" scheme="http://www.flickr.com/photos/tags/" />
		<category term="va" scheme="http://www.flickr.com/photos/tags/" />
		<category term="badge" scheme="http://www.flickr.com/photos/tags/" />
		<category term="tubing" scheme="http://www.flickr.com/photos/tags/" />
		<category term="fuji160c" scheme="http://www.flickr.com/photos/tags/" />
		<category term="anfamiliebarth" scheme="http://www.flickr.com/photos/tags/" />
		<category term="canon24l" scheme="http://www.flickr.com/photos/tags/" />
                	</entry>
	<entry>
		<title>Jeff vs Tom</title>
		<link rel="alternate" type="text/html" href="http://www.flickr.com/photos/a-barth/2640019371/in/set-72157603970496952/"/>
		<id>tag:flickr.com,2005:/photo/2640019371/in/set-72157603970496952</id>
		<published>2009-07-09T21:45:50Z</published>
		<updated>2009-07-09T21:45:50Z</updated>
                <dc:date.Taken>2008-06-01T00:00:00-08:00</dc:date.Taken>
		<content type="html">&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/people/a-barth/&quot;&gt;Alex Barth&lt;/a&gt; posted a photo:&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/photos/a-barth/2640019371/&quot; title=&quot;Jeff vs Tom&quot;&gt;&lt;img src=&quot;http://farm4.static.flickr.com/3261/2640019371_495c3f51a2_m.jpg&quot; width=&quot;240&quot; height=&quot;159&quot; alt=&quot;Jeff vs Tom&quot; /&gt;&lt;/a&gt;&lt;/p&gt;


</content>
		<author>
			<name>Alex Barth</name>
			<uri>http://www.flickr.com/people/a-barth/</uri>
					</author>
		<link rel="license" type="text/html" href="http://creativecommons.org/licenses/by-nc/2.0/deed.en" />
        <link rel="enclosure" type="image/jpeg" href="<?php print $image_urls[1]; ?>" />

		<category term="b" scheme="http://www.flickr.com/photos/tags/" />
		<category term="blackandwhite" scheme="http://www.flickr.com/photos/tags/" />
		<category term="bw" scheme="http://www.flickr.com/photos/tags/" />
		<category term="jeff" scheme="http://www.flickr.com/photos/tags/" />
		<category term="tom" scheme="http://www.flickr.com/photos/tags/" />
		<category term="washingtondc" scheme="http://www.flickr.com/photos/tags/" />
		<category term="blackwhite" scheme="http://www.flickr.com/photos/tags/" />
		<category term="dc" scheme="http://www.flickr.com/photos/tags/" />
		<category term="nikon" scheme="http://www.flickr.com/photos/tags/" />
		<category term="wideangle" scheme="http://www.flickr.com/photos/tags/" />
		<category term="ilfordhp5" scheme="http://www.flickr.com/photos/tags/" />
		<category term="foosball" scheme="http://www.flickr.com/photos/tags/" />
		<category term="20mm" scheme="http://www.flickr.com/photos/tags/" />
		<category term="nikonfe2" scheme="http://www.flickr.com/photos/tags/" />
		<category term="800asa" scheme="http://www.flickr.com/photos/tags/" />
		<category term="foosballtable" scheme="http://www.flickr.com/photos/tags/" />
		<category term="wuzler" scheme="http://www.flickr.com/photos/tags/" />
		<category term="wuzln" scheme="http://www.flickr.com/photos/tags/" />
		<category term="tischfusball" scheme="http://www.flickr.com/photos/tags/" />
		<category term="jeffmiccolis" scheme="http://www.flickr.com/photos/tags/" />
		<category term="ilfordhp5800asa" scheme="http://www.flickr.com/photos/tags/" />
		<category term="widean" scheme="http://www.flickr.com/photos/tags/" />
                	</entry>
	<entry>
		<title>Attersee 1</title>
		<link rel="alternate" type="text/html" href="http://www.flickr.com/photos/a-barth/3686290986/in/set-72157603970496952/"/>
		<id>tag:flickr.com,2005:/photo/3686290986/in/set-72157603970496952</id>
		<published>2009-07-09T21:42:01Z</published>
		<updated>2009-07-09T21:42:01Z</updated>
                <dc:date.Taken>2009-06-01T00:00:00-08:00</dc:date.Taken>
		<content type="html">&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/people/a-barth/&quot;&gt;Alex Barth&lt;/a&gt; posted a photo:&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/photos/a-barth/3686290986/&quot; title=&quot;Attersee 1&quot;&gt;&lt;img src=&quot;http://farm4.static.flickr.com/3606/3686290986_334c427e8c_m.jpg&quot; width=&quot;240&quot; height=&quot;238&quot; alt=&quot;Attersee 1&quot; /&gt;&lt;/a&gt;&lt;/p&gt;


&lt;p&gt;Upper Austria, 2009&lt;/p&gt;</content>
		<author>
			<name>Alex Barth</name>
			<uri>http://www.flickr.com/people/a-barth/</uri>
					</author>
		<link rel="license" type="text/html" href="http://creativecommons.org/licenses/by-nc/2.0/deed.en" />
        <link rel="enclosure" type="image/jpeg" href="<?php print $image_urls[2]; ?>" />

		<category term="lake" scheme="http://www.flickr.com/photos/tags/" />
		<category term="green" scheme="http://www.flickr.com/photos/tags/" />
		<category term="water" scheme="http://www.flickr.com/photos/tags/" />
		<category term="austria" scheme="http://www.flickr.com/photos/tags/" />
		<category term="holga" scheme="http://www.flickr.com/photos/tags/" />
		<category term="toycamera" scheme="http://www.flickr.com/photos/tags/" />
		<category term="ishootfilm" scheme="http://www.flickr.com/photos/tags/" />
		<category term="fujireala" scheme="http://www.flickr.com/photos/tags/" />
		<category term="badge" scheme="http://www.flickr.com/photos/tags/" />
		<category term="100asa" scheme="http://www.flickr.com/photos/tags/" />
		<category term="attersee" scheme="http://www.flickr.com/photos/tags/" />
		<category term="plasticlens" scheme="http://www.flickr.com/photos/tags/" />
		<category term="colornegative" scheme="http://www.flickr.com/photos/tags/" />
                	</entry>
	<entry>
		<title>H Street North East</title>
		<link rel="alternate" type="text/html" href="http://www.flickr.com/photos/a-barth/2640845934/in/set-72157603970496952/"/>
		<id>tag:flickr.com,2005:/photo/2640845934/in/set-72157603970496952</id>
		<published>2008-09-23T13:26:13Z</published>
		<updated>2008-09-23T13:26:13Z</updated>
                <dc:date.Taken>2008-06-01T00:00:00-08:00</dc:date.Taken>
		<content type="html">&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/people/a-barth/&quot;&gt;Alex Barth&lt;/a&gt; posted a photo:&lt;/p&gt;

&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/photos/a-barth/2640845934/&quot; title=&quot;H Street North East&quot;&gt;&lt;img src=&quot;http://farm4.static.flickr.com/3083/2640845934_85c11e5a18_m.jpg&quot; width=&quot;240&quot; height=&quot;159&quot; alt=&quot;H Street North East&quot; /&gt;&lt;/a&gt;&lt;/p&gt;


&lt;p&gt;Washington DC 2008&lt;br /&gt;
&lt;a href=&quot;http://dcist.com/2008/07/07/photo_of_the_day_july_7_2008.php&quot;&gt;Photo of the Day July 7 on DCist&lt;/a&gt;&lt;/p&gt;</content>
		<author>
			<name>Alex Barth</name>
			<uri>http://www.flickr.com/people/a-barth/</uri>
					</author>
		<link rel="license" type="text/html" href="http://creativecommons.org/licenses/by-nc/2.0/deed.en" />
        <link rel="enclosure" type="image/jpeg" href="<?php print $image_urls[3]; ?>" />

		<category term="nightphotography" scheme="http://www.flickr.com/photos/tags/" />
		<category term="b" scheme="http://www.flickr.com/photos/tags/" />
		<category term="blackandwhite" scheme="http://www.flickr.com/photos/tags/" />
		<category term="bw" scheme="http://www.flickr.com/photos/tags/" />
		<category term="night" scheme="http://www.flickr.com/photos/tags/" />
		<category term="washingtondc" scheme="http://www.flickr.com/photos/tags/" />
		<category term="blackwhite" scheme="http://www.flickr.com/photos/tags/" />
		<category term="dc" scheme="http://www.flickr.com/photos/tags/" />
		<category term="nikon" scheme="http://www.flickr.com/photos/tags/" />
		<category term="dof" scheme="http://www.flickr.com/photos/tags/" />
		<category term="wideangle" scheme="http://www.flickr.com/photos/tags/" />
		<category term="explore" scheme="http://www.flickr.com/photos/tags/" />
		<category term="ilfordhp5" scheme="http://www.flickr.com/photos/tags/" />
		<category term="badge" scheme="http://www.flickr.com/photos/tags/" />
		<category term="dcist" scheme="http://www.flickr.com/photos/tags/" />
		<category term="20mm" scheme="http://www.flickr.com/photos/tags/" />
		<category term="hstreet" scheme="http://www.flickr.com/photos/tags/" />
		<category term="nikonfe2" scheme="http://www.flickr.com/photos/tags/" />
		<category term="800asa" scheme="http://www.flickr.com/photos/tags/" />
		<category term="hstreetne" scheme="http://www.flickr.com/photos/tags/" />
		<category term="anfamiliebarth" scheme="http://www.flickr.com/photos/tags/" />
		<category term="ilfordhp5800asa" scheme="http://www.flickr.com/photos/tags/" />
		<category term="hstreetbynight" scheme="http://www.flickr.com/photos/tags/" />
		<category term="forlaia" scheme="http://www.flickr.com/photos/tags/" />
                	</entry>
  <entry>
 		<title>La Fayette Park</title>
 		<link rel="alternate" type="text/html" href="http://www.flickr.com/photos/a-barth/4209685951/in/set-72157603970496952/"/>
 		<id>tag:flickr.com,2005:/photo/4209685951/in/set-72157603970496952</id>
 		<published>2009-07-09T21:48:04Z</published>
 		<updated>2009-07-09T21:48:04Z</updated>
                 <dc:date.Taken>2009-05-01T00:00:00-08:00</dc:date.Taken>
 		<content type="html">&lt;p&gt;&lt;a href=&quot;http://www.flickr.com/people/a-barth/&quot;&gt;Alex Barth&lt;/a&gt; posted a photo:&lt;/p&gt;

 &lt;p&gt;&lt;a href=&quot;http://www.flickr.com/photos/a-barth/3596408735/&quot; title=&quot;Tubing is fun&quot;&gt;&lt;img src=&quot;http://farm3.staticflickr.com/2675/4209685951_cb073de96f_m.jpg&quot; width=&quot;239&quot; height=&quot;240&quot; alt=&quot;La Fayette park&quot; /&gt;&lt;/a&gt;&lt;/p&gt;


 &lt;p&gt;Virginia, 2009&lt;/p&gt;</content>
 		<author>
 			<name>Alex Barth</name>
 			<uri>http://www.flickr.com/people/a-barth/</uri>
 					</author>
 		<link rel="license" type="text/html" href="http://creativecommons.org/licenses/by-nc/2.0/deed.en" />
         <link rel="enclosure" type="image/jpeg" href="<?php print $image_urls[4]; ?>" />

 		<category term="color" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="film" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="virginia" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="awesome" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="ishootfilm" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="va" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="badge" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="tubing" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="fuji160c" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="anfamiliebarth" scheme="http://www.flickr.com/photos/tags/" />
 		<category term="canon24l" scheme="http://www.flickr.com/photos/tags/" />
                 	</entry>
</feed>